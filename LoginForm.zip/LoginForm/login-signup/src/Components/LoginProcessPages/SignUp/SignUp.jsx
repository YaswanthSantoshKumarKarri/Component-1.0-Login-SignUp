import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import './SignUp.css'

import UserAuthService from '../../../Services/UserAuthService.js'

const SignUp = () => {
    const currentDate=new Date();

    const [roleSelect,setRoleSelect]=useState(true)
    const [log,setLog]=useState(false);
    const [Digi,setDigi]=useState(false);
    const [vehicle,setVehicle]=useState(false);
    const [bankAcc,setBankAcc]=useState(false);
    const [UserformData, setUserFormData] = useState({
        userId:0,
        userName: '',
        userEmail: '',
        userPassword:'',
        confirmUserPassword:'',
        role:'',
        userMobileNumber:'',
        userGender:'',
        userAge:'',
        userAdharId:'',
        userPanId:'',
        userAddress:'',
        userStates:'',
        userDOJ:currentDate.toLocaleString()
      });
      const [DriverformData, setDriverFormData] = useState({
        userName: '',
        userEmail: '',
        userPassword:'',
        confirmUserPassword:'',
        role:'',
        userMobileNumber:'',
        userGender:'',
        userAge:'',
        userAdharId:'',
        userPanId:'',
        userAddress:'',
        userStates:'',
        VehicleLicensePlateNo:'',
        ModelName:'',
        DrivingLicenseNo:'',
        VehicleTypes:'',
        BankAccNo:'',
        IFSCcode:'',
        bankName:'',
        bankAccType:'',
        DriverDateOfJoining:currentDate.toLocaleString(),
        rating:0,
        TotalNoOfRides:0,
        TotalKmTravelled:0
      });
    
      const navigate = useNavigate();
    
    //-------------------------setting form data--------------------

      const handleChange = (e) => {
        const { name, value } = e.target;
        if(value==="User" || UserformData.role==="User"){
            setUserFormData({ ...UserformData, [name]: value });
        }else if(value==="Driver" || DriverformData.role==="Driver"){
            setDriverFormData({...DriverformData,[name]: value});
        }
      };      

      //--------------------------NEXT BTN leading to new form-------
      const handleLoginDataNext=()=>{
        setLog(true);
        setRoleSelect(false);
      }
    
      const handlePersonalDataNext=()=>{
        setDigi(true);
        setLog(false);
        }
    
        const handleVehicalDataNext=()=>{
            setVehicle(true);
            setDigi(false);
        }
        const handleBankAccDataNext=()=>{
            setVehicle(false);
            setBankAcc(true);
        }
        //-----------------submission data--------------------------
          const handleUserSubmission=(e)=>{
            e.preventDefault();
            UserAuthService.saveAuth(UserformData).then((response)=>{
                const responseData=response.data;
                navigate("/Profile",{ state:  {responseData} });
            })
            .catch((error)=>{console.log(error);});
          }

        const handleDriverDataSubmission=(e)=>{
            e.preventDefault();
            if(UserformData.userPassword===UserformData.confirmUserPassword){
                navigate("/Profile");
            }else{
                alert("Password ,miss match")
            }
        };
  return (
    <div className='RoleContainer'>
        <div className="RoleContainerBox">
          <div className="RoleLeft">
            <div className="RoleLeftInner">
              <h1>Welcome to SignUp</h1>
              <p>Already have an Account?</p>
              <button><Link className='Link' to="/SignIn">Sign In</Link></button>
            </div>
          </div>
          <div className="RoleRight">
              <h2>SignUp Here</h2>
              <form action="">
              {roleSelect && (
                    <>
                        <select name="role" style={{height:"50px",marginTop:"100px"}} onChange={handleChange} required >
                            <option value="" disabled selected hidden>Choose an option</option>
                            <option value="User">User</option>
                            <option value="Driver">Driver</option>
                        </select>
                        <button style={{height:"50px"}} onClick={handleLoginDataNext}>Next</button>
                    </>  
                )}
                {log && (
                    <>
                        <input type="text" name='userName' onChange={handleChange} placeholder='Enter User Name here' required/>
                        <input type="email" name='userEmail' onChange={handleChange} placeholder='Enter User Email here' required/>
                        <input type="number" name='userMobileNumber' onChange={handleChange} placeholder='Enter User Mobile Number here' required/>
                        <input type="password" name='userPassword' onChange={handleChange} placeholder='Enter User Password here' required/>
                        <input type="password" name='confirmUserPassword' onChange={handleChange} placeholder='Confirm User Password here' required/>
                    <button onClick={handlePersonalDataNext}>Next</button>
                    </>  
                )}                
                {Digi && (
                    <>
                        <div className="userGenderCoosing">
                            <input onChange={handleChange} type='radio' name="userGender" value="Male"/>
                            <label htmlFor="userGender">Male</label>
                            <input onChange={handleChange} type="radio" name="userGender" value="Female"/>
                            <label htmlFor="userGender">Female</label>
                        </div>
                        <input type="number" name='userAge' placeholder='Enter User Age Here'/>
                        <input type="text" name='userAdharId' onChange={handleChange} placeholder='Enter User AdharId here' required/>
                        <input type="text" name='userPanId' onChange={handleChange} placeholder='Enter User PanId here' required/>
                        <input type="text" name='userAddress' onChange={handleChange} placeholder='Enter User Address here' required/>
                        <select name="userStates" onChange={handleChange} required>
                            <option value="" disabled selected hidden>Choose an option</option>
                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                            <option value="Assam">Assam</option>
                            <option value="Bihar">Bihar</option>
                            <option value="Chhattisgarh">Chhattisgarh</option>
                            <option value="Goa">Goa</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Haryana">Haryana</option>
                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                            <option value="Jharkhand">Jharkhand</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Kerala">Kerala</option>
                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Manipur">Manipur</option>
                            <option value="Meghalaya">Meghalaya</option>
                            <option value="Mizoram">Mizoram</option>
                            <option value="Nagaland">Nagaland</option>
                            <option value="Odisha">Odisha</option>
                            <option value="Punjab">Punjab</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Sikkim">Sikkim</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Telangana">Telangana</option>
                            <option value="Tripura">Tripura</option>
                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                            <option value="Uttarakhand">Uttarakhand</option>
                            <option value="West Bengal">West Bengal</option>
                        </select>
                        {UserformData.role==="User" ? (
                            <><button onClick={handleUserSubmission}>Submit</button></>
                        ):(<>
                            <><button onClick={handleVehicalDataNext}>Next</button></>
                        </>)}
                    </>
                )}
                {vehicle && (
                    <>
                        <input type="text" name='VehicleLicensePlateNo' onChange={handleChange} placeholder='Enter Vehicle License Plate Number' required/>
                        <input type="text" name='ModelName' onChange={handleChange} placeholder='Enter Vehicle Model Name here' required/>
                        <input type="text" name='DrivingLicenseNo' onChange={handleChange} placeholder='Enter Driving License Number here' required/>
                        <select name="VehicleTypes" required>
                            <option value="" disabled selected hidden>Choose an option</option>
                            <optgroup label="3 Seater">
                                <option value="Auto">Auto</option>
                            </optgroup>
                            <optgroup label="4 Seater">
                                <option value="Hatchback">Hatchback</option>
                                <option value="Sedan">Sedan</option>
                            </optgroup>
                            <optgroup label="7 Seater">
                                <option value="SUV">SUV</option>
                                <option value="MPV">MPV</option>
                            </optgroup>
                            <optgroup label="7+ Seater">
                                <option value="Van">Van</option>
                            </optgroup>
                        </select>
                        <button onClick={handleBankAccDataNext}>Next</button>
                    </>  
                )}
                  {bankAcc && (
                    <>
                        <input type="text" name='BankAccNo' onChange={handleChange} placeholder='Enter Bank Account Number here' required/>
                        <input type="text" name='IFSCcode' onChange={handleChange} placeholder='Enter Bank IFSC code here' required/>
                        <select name="bankName" required>
                            <option value="" disabled selected hidden>Choose an option</option>
                            <option value="State Bank of India">State Bank of India</option>
                            <option value="HDFC Bank">HDFC Bank</option>
                            <option value="ICICI Bank">ICICI Bank</option>
                            <option value="Axis Bank">Axis Bank</option>
                            <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                            <option value="Bank of Baroda">Bank of Baroda</option>
                            <option value="Punjab National Bank">Punjab National Bank</option>
                            <option value="Canara Bank">Canara Bank</option>
                            <option value="Union Bank of India">Union Bank of India</option>
                        </select>
                        <select name="bankAccType" required>
                            <option value="" disabled selected hidden>Choose an option</option>
                            <option value="State Bank of India">Current</option>
                            <option value="HDFC Bank">Savings</option>
                        </select>
                        <button onClick={handleDriverDataSubmission}>Submit</button>
                    </>
                    )}
              </form>
          </div>
        </div>
    </div>
  )
}

export default SignUp