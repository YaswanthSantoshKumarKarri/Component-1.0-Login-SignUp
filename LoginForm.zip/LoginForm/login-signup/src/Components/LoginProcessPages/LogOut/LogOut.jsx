import React from 'react'
import { useNavigate } from 'react-router-dom';

import "./LogOut.css"

const LogOut = () => {
  
}

export default LogOut;